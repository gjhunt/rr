library(testthat)
library(rrscale)

test_check("rrscale")
